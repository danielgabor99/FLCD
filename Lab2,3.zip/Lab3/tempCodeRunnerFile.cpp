
                    pif<<(*it)[0]<<string